-- CAT HUB key verification example.
-- Replace API_BASE with your deployed Netlify domain.
-- Do not place ADMIN_SECRET or DATABASE_URL in this file.
local API_BASE = "https://cathub-key-ggs.netlify.app"
local HttpService = game:GetService("HttpService")

local function verifyKey(key)
    local ok, response = pcall(function()
        return HttpService:RequestAsync({
            Url = API_BASE .. "/api/verify-key",
            Method = "POST",
            Headers = { ["Content-Type"] = "application/json" },
            Body = HttpService:JSONEncode({ key = key })
        })
    end)
    if not ok or not response.Success then
        return false, "Could not reach CAT HUB verification API"
    end
    local decodedOk, data = pcall(function()
        return HttpService:JSONDecode(response.Body)
    end)
    if not decodedOk then return false, "Invalid API response" end
    return data.valid == true, data.reason or data.status or "unknown"
end

-- Example:
-- local valid, status = verifyKey("cat-PASTE_YOUR_KEY_HERE")
-- print(valid, status)
return verifyKey
