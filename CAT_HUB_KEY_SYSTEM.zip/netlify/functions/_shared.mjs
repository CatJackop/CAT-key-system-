import { neon } from '@neondatabase/serverless';
import crypto from 'node:crypto';

export function json(statusCode, body, extraHeaders={}) {
  return { statusCode, headers: {'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':process.env.ALLOWED_ORIGIN || '*', ...extraHeaders}, body: JSON.stringify(body) };
}
export function readBody(event) {
  try { return JSON.parse(event.body || '{}'); } catch { return null; }
}
export function sqlClient() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is not configured');
  return neon(process.env.DATABASE_URL);
}
export function hashKey(key) { return crypto.createHash('sha256').update(key).digest('hex'); }
export function makeKey() {
  return 'cat-' + crypto.randomBytes(12).toString('hex').toUpperCase();
}
export function adminOK(event) {
  const supplied = event.headers?.['x-admin-secret'] || event.headers?.['X-Admin-Secret'];
  const expected = process.env.ADMIN_SECRET;
  if (!expected || !supplied) return false;
  const a = Buffer.from(String(supplied)); const b = Buffer.from(String(expected));
  return a.length === b.length && crypto.timingSafeEqual(a,b);
}
export function isMethod(event, method) { return event.httpMethod === method; }
