import { json, readBody, sqlClient, adminOK } from './_shared.mjs';
export async function handler(event) {
  if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
  if(!adminOK(event)) return json(401,{error:'Unauthorized'});
  const body=readBody(event);
  if(!body || typeof body.id!=='string') return json(400,{error:'id is required'});
  try {
    const sql=sqlClient();
    const rows=await sql`UPDATE hub_keys SET revoked_at=NOW() WHERE id=${body.id} AND revoked_at IS NULL RETURNING id`;
    return rows.length?json(200,{ok:true}):json(404,{error:'Key not found or already revoked'});
  } catch(e) { return json(500,{error:'Could not revoke key'}); }
}
