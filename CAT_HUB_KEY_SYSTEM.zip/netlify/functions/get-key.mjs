import { json, readBody, sqlClient, hashKey, makeKey } from './_shared.mjs';
export async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405,{error:'Method not allowed'});
  const body=readBody(event); if(body===null) return json(400,{error:'Invalid JSON'});
  try {
    const sql=sqlClient();
    // Public issuance uses a default 24-hour duration; the clock starts at first successful verification.
    const key=makeKey();
    await sql`INSERT INTO hub_keys (key_hash,key_prefix,label,duration_hours) VALUES (${hashKey(key)},'cat-',NULL,24)`;
    return json(201,{key,activation:'first_use',duration_hours:24});
  } catch(e) { return json(500,{error:'Could not issue key'}); }
}
