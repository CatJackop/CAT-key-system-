import { json, readBody, sqlClient, hashKey, makeKey, adminOK } from './_shared.mjs';
export async function handler(event) {
  if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
  if(!adminOK(event)) return json(401,{error:'Unauthorized'});
  const body=readBody(event);
  const durationHours=Number(body?.durationHours);
  if(!Number.isInteger(durationHours)||durationHours<1||durationHours>8760) return json(400,{error:'durationHours must be an integer from 1 to 8760'});
  const label=typeof body.label==='string'?body.label.slice(0,80):null;
  try {
    const sql=sqlClient(); const key=makeKey();
    await sql`INSERT INTO hub_keys (key_hash,key_prefix,label,duration_hours) VALUES (${hashKey(key)},'cat-',${label},${durationHours})`;
    return json(201,{key,activation:'first_use',duration_hours:durationHours});
  } catch(e) { return json(500,{error:'Could not create key'}); }
}
