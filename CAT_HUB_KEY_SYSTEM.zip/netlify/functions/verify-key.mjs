import { json, readBody, sqlClient, hashKey } from './_shared.mjs';
export async function handler(event) {
  if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
  const body=readBody(event); if(!body || typeof body.key!=='string') return json(400,{valid:false,reason:'missing_key'});
  const key=body.key.trim();
  if(!/^cat-[A-F0-9]{24}$/.test(key)) return json(200,{valid:false,reason:'invalid_key'});
  try {
    const sql=sqlClient(); const h=hashKey(key);
    const rows=await sql`SELECT id,duration_hours,activated_at,expires_at,revoked_at FROM hub_keys WHERE key_hash=${h} LIMIT 1`;
    if(!rows.length) return json(200,{valid:false,reason:'invalid_key'});
    let k=rows[0];
    if(k.revoked_at) return json(200,{valid:false,reason:'revoked'});
    if(!k.activated_at) {
      const activated=await sql`UPDATE hub_keys SET activated_at=NOW(), expires_at=NOW() + (duration_hours * INTERVAL '1 hour'), last_verified_at=NOW() WHERE id=${k.id} AND activated_at IS NULL AND revoked_at IS NULL RETURNING expires_at,activated_at`;
      if(activated.length) { k={...k,...activated[0]}; }
      else {
        const refreshed=await sql`SELECT activated_at,expires_at,revoked_at FROM hub_keys WHERE id=${k.id} LIMIT 1`;
        if(!refreshed.length || refreshed[0].revoked_at) return json(200,{valid:false,reason:'revoked'});
        k={...k,...refreshed[0]};
      }
    } else {
      await sql`UPDATE hub_keys SET last_verified_at=NOW() WHERE id=${k.id}`;
    }
    const check=await sql`SELECT (expires_at > NOW()) AS active, expires_at, activated_at FROM hub_keys WHERE id=${k.id} LIMIT 1`;
    if(!check[0]?.active) return json(200,{valid:false,reason:'expired',status:'expired',expires_at:check[0]?.expires_at || k.expires_at});
    return json(200,{valid:true,status:'active',activated_at:check[0].activated_at,expires_at:check[0].expires_at});
  } catch(e) { return json(500,{valid:false,reason:'server_error'}); }
}
