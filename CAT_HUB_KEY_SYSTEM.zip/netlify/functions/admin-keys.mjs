import { json, sqlClient, hashKey, adminOK } from './_shared.mjs';
export async function handler(event) {
  if(event.httpMethod!=='GET') return json(405,{error:'Method not allowed'});
  if(!adminOK(event)) return json(401,{error:'Unauthorized'});
  try {
    const sql=sqlClient();
    const rows=await sql`SELECT id,key_hash,label,created_at,duration_hours,activated_at,expires_at,revoked_at FROM hub_keys ORDER BY created_at DESC LIMIT 500`;
    // This starter stores only hashes, so keys cannot be reconstructed after creation.
    // Listing uses a redacted identifier rather than exposing raw keys.
    return json(200,{keys:rows.map(k=>({key:'cat-••••••••••••••••••••••••',id:k.id,label:k.label,created_at:k.created_at,duration_hours:k.duration_hours,activated_at:k.activated_at,expires_at:k.expires_at,status:k.revoked_at?'revoked':(!k.activated_at?'unused':(new Date(k.expires_at)<=new Date()?'expired':'active'))}))});
  } catch(e) { return json(500,{error:'Could not load keys'}); }
}
